package com.duocuc.pedidosBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
